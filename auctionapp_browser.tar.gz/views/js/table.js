$(document).ready(function(){
	tableApp.init();
});