#!/bin/sh

export PEER=$GOPATH/src/github.com/hyperledger/fabric/peer/peer
